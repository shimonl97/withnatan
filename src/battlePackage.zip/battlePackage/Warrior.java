package battlePackage;

public class Warrior extends Player {


	@Override
	public  PlayerType getPlayerType() {
		return PlayerType.warrior;
	}

	public Warrior(int health, int mana, int attackDamage, float attackSpeed, String name) {
		super(health, mana, attackDamage, attackSpeed, name);
		// TODO Auto-generated constructor stub
	}
	
	}
	

	
		
	
	


