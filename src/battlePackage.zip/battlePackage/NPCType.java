package battlePackage;

public enum NPCType {

}
