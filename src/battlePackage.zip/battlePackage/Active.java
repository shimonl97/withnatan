package battlePackage;

public enum Active {
blast,heal;
}
