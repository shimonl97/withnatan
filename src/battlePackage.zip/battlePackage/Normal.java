package battlePackage;

public abstract class Normal extends Enemy {

	public Normal(String name) {
		super(name);
	}

	


}
