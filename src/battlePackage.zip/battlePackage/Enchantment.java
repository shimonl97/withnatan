package battlePackage;

public enum Enchantment {
ofPower,ofSpeed,ofKnowledge,ofResistance,none;
}
