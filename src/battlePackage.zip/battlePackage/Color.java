package battlePackage;

public enum Color {
yellow,orange,red,blue,green,black,white,purple,gray,pink
}
