package battlePackage;

public interface Item {

}
