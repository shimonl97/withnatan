package battlePackage;

public enum PlayerType {
mage,warrior,archer;
}
