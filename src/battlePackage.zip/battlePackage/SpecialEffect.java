package battlePackage;

public enum SpecialEffect {
desolating,bash,none;
}
